import React, { useState, useEffect } from 'react';
import { TabType, ImageFile } from './types';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { PrivacyBanner } from './components/PrivacyBanner';
import { ImageUploader } from './components/ImageUploader';
import { BackgroundRemover } from './components/BackgroundRemover';
import { FormatConverter } from './components/FormatConverter';
import { PdfConverter } from './components/PdfConverter';
import { ImageResizer } from './components/ImageResizer';
import { GuideModal } from './components/GuideModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('bg-remover');
  const [activeImage, setActiveImage] = useState<ImageFile | null>(null);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('imagestudio_theme');
      if (saved !== null) return saved === 'dark';
    } catch (e) {}
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [isGuideOpen, setIsGuideOpen] = useState<boolean>(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      try {
        localStorage.setItem('imagestudio_theme', 'dark');
      } catch (e) {}
    } else {
      document.documentElement.classList.remove('dark');
      try {
        localStorage.setItem('imagestudio_theme', 'light');
      } catch (e) {}
    }
  }, [darkMode]);

  const handleImageSelected = (img: ImageFile) => {
    setActiveImage(img);
  };

  const handleClearImage = () => {
    setActiveImage(null);
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Header */}
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenGuide={() => setIsGuideOpen(true)}
      />

      {/* Cross-Platform Navigation Tabs */}
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <PrivacyBanner />

        {/* Tab Content Rendering */}
        <div className="mt-4">
          {activeTab === 'bg-remover' && (
            <div>
              {!activeImage ? (
                <ImageUploader
                  onImageSelected={handleImageSelected}
                  title="Upload Image to Remove Background"
                  subtitle="Instantly auto-detect background or use color keying — 100% locally on your device"
                />
              ) : (
                <BackgroundRemover image={activeImage} onClearImage={handleClearImage} />
              )}
            </div>
          )}

          {activeTab === 'converter' && (
            <div>
              {!activeImage ? (
                <ImageUploader
                  onImageSelected={handleImageSelected}
                  title="Upload Image for Format Conversion"
                  subtitle="Seamlessly convert between JPG, JPEG, PNG, WEBP with custom quality settings"
                />
              ) : (
                <FormatConverter image={activeImage} onClearImage={handleClearImage} />
              )}
            </div>
          )}

          {activeTab === 'pdf' && (
            <div>
              <PdfConverter initialImages={activeImage ? [activeImage] : []} />
            </div>
          )}

          {activeTab === 'resize' && (
            <div>
              {!activeImage ? (
                <ImageUploader
                  onImageSelected={handleImageSelected}
                  title="Upload Image to Resize & Edit"
                  subtitle="Adjust dimensions, scale ratio, orientation, brightness, contrast, and color filters"
                />
              ) : (
                <ImageResizer image={activeImage} onClearImage={handleClearImage} />
              )}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            ImageStudio Pro • Clean, Ad-Free & Offline-First Device Tool
          </p>
          <div className="flex items-center space-x-4 text-slate-600 dark:text-slate-400 font-semibold">
            <button onClick={() => setIsGuideOpen(true)} className="hover:underline">
              Privacy Guarantee
            </button>
            <span>•</span>
            <span>Local Canvas & WebAssembly Engine</span>
          </div>
        </div>
      </footer>

      {/* How-To & Privacy Modal */}
      <GuideModal isOpen={isGuideOpen} onClose={() => setIsGuideOpen(false)} />
    </div>
  );
}
