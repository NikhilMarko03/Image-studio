/**
 * Generates lightweight, high-quality sample canvas data URLs for quick instant user testing
 */

export function createSampleProductImage(): string {
  const canvas = document.createElement('canvas');
  canvas.width = 800;
  canvas.height = 800;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background: Studio light blue gradient
  const bgGradient = ctx.createRadialGradient(400, 400, 50, 400, 400, 550);
  bgGradient.addColorStop(0, '#e2e8f0');
  bgGradient.addColorStop(0.6, '#cbd5e1');
  bgGradient.addColorStop(1, '#94a3b8');
  ctx.fillStyle = bgGradient;
  ctx.fillRect(0, 0, 800, 800);

  // Soft shadow
  ctx.save();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.18)';
  ctx.beginPath();
  ctx.ellipse(400, 620, 220, 45, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Object: High end camera / gadget with sharp edges
  ctx.save();
  // Main Body
  const bodyGrad = ctx.createLinearGradient(200, 250, 600, 550);
  bodyGrad.addColorStop(0, '#1e293b');
  bodyGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = bodyGrad;
  ctx.beginPath();
  ctx.roundRect(220, 320, 360, 240, 24);
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = '#334155';
  ctx.stroke();

  // Leather Grip accent
  ctx.fillStyle = '#475569';
  ctx.beginPath();
  ctx.roundRect(240, 340, 80, 200, 12);
  ctx.fill();

  // Lens Mount Outer ring
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.arc(430, 440, 100, 0, Math.PI * 2);
  ctx.fill();

  // Lens Glass
  const lensGrad = ctx.createRadialGradient(420, 430, 10, 430, 440, 95);
  lensGrad.addColorStop(0, '#38bdf8');
  lensGrad.addColorStop(0.5, '#0284c7');
  lensGrad.addColorStop(0.9, '#0369a1');
  lensGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = lensGrad;
  ctx.beginPath();
  ctx.arc(430, 440, 90, 0, Math.PI * 2);
  ctx.fill();

  // Lens Reflection
  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.beginPath();
  ctx.ellipse(400, 410, 40, 15, -Math.PI / 4, 0, Math.PI * 2);
  ctx.fill();

  // Top Dial & Button
  ctx.fillStyle = '#334155';
  ctx.beginPath();
  ctx.roundRect(480, 290, 50, 30, 6);
  ctx.fill();
  ctx.fillStyle = '#ef4444'; // Red shutter dot
  ctx.beginPath();
  ctx.arc(320, 305, 12, 0, Math.PI * 2);
  ctx.fill();

  // Label text
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText('CAM-PRO X', 250, 370);
  ctx.restore();

  return canvas.toDataURL('image/png');
}

export function createSamplePortraitImage(): string {
  const canvas = document.createElement('canvas');
  canvas.width = 800;
  canvas.height = 800;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Solid green background (Great for Chroma keying tests!)
  ctx.fillStyle = '#10b981';
  ctx.fillRect(0, 0, 800, 800);

  // Subject Avatar Silhouette / Person
  ctx.save();
  // Head
  ctx.fillStyle = '#f87171';
  ctx.beginPath();
  ctx.arc(400, 320, 120, 0, Math.PI * 2);
  ctx.fill();

  // Hair / Cap
  ctx.fillStyle = '#1e1b4b';
  ctx.beginPath();
  ctx.arc(400, 290, 130, Math.PI, Math.PI * 2);
  ctx.fill();

  // Shoulders & Shirt
  ctx.fillStyle = '#3b82f6';
  ctx.beginPath();
  ctx.ellipse(400, 600, 240, 180, 0, Math.PI, 0, true);
  ctx.fill();

  // Glasses
  ctx.lineWidth = 8;
  ctx.strokeStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(350, 320, 35, 0, Math.PI * 2);
  ctx.arc(450, 320, 35, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(385, 320);
  ctx.lineTo(415, 320);
  ctx.stroke();

  // Smile
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.arc(400, 360, 45, 0.1 * Math.PI, 0.9 * Math.PI);
  ctx.stroke();

  ctx.restore();

  return canvas.toDataURL('image/jpeg', 0.92);
}

export function createSampleDocumentImage(): string {
  const canvas = document.createElement('canvas');
  canvas.width = 800;
  canvas.height = 1000;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Wooden desk background
  ctx.fillStyle = '#78350f';
  ctx.fillRect(0, 0, 800, 1000);

  // Paper Document tilted
  ctx.save();
  ctx.translate(400, 500);
  ctx.rotate(-0.03);

  // Paper Shadow
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.fillRect(-290, -390, 600, 800);

  // White Paper sheet
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(-300, -400, 600, 800);

  // Document Content Header
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 32px sans-serif';
  ctx.fillText('OFFICIAL INVOICE & REPORT', -250, -320);

  ctx.strokeStyle = '#2563eb';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(-250, -290);
  ctx.lineTo(250, -290);
  ctx.stroke();

  // Invoice Details
  ctx.fillStyle = '#334155';
  ctx.font = '18px sans-serif';
  ctx.fillText('Date: July 28, 2026', -250, -240);
  ctx.fillText('Invoice #: INV-2026-889', -250, -210);
  ctx.fillText('Client: Global Studio Corp', -250, -180);

  // Mock Table
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(-250, -130, 500, 40);

  ctx.fillStyle = '#1e293b';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('ITEM DESCRIPTION', -230, -105);
  ctx.fillText('QTY', 100, -105);
  ctx.fillText('PRICE', 180, -105);

  // Rows
  const items = [
    ['Digital Image Processing Suite', '1', '$199.00'],
    ['PDF Export Engine License', '1', '$149.00'],
    ['Batch Conversion Module', '1', '$99.00'],
    ['On-Device Privacy Core', '1', 'FREE'],
  ];

  let y = -50;
  items.forEach(([desc, qty, price]) => {
    ctx.fillStyle = '#475569';
    ctx.font = '16px sans-serif';
    ctx.fillText(desc, -230, y);
    ctx.fillText(qty, 110, y);
    ctx.fillText(price, 180, y);
    y += 40;
  });

  // Total Box
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(50, 150, 200, 60);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('TOTAL: $447.00', 65, 188);

  // Stamp / Watermark
  ctx.save();
  ctx.rotate(-0.2);
  ctx.strokeStyle = '#16a34a';
  ctx.lineWidth = 6;
  ctx.strokeRect(-180, 180, 220, 80);
  ctx.fillStyle = '#16a34a';
  ctx.font = 'bold 36px sans-serif';
  ctx.fillText('PAID FULL', -165, 235);
  ctx.restore();

  ctx.restore();

  return canvas.toDataURL('image/jpeg', 0.9);
}
