import { BgRemovalSettings, OutputFormat, ResizeSettings } from '../types';

/**
 * Loads an HTMLImageElement from a Data URL asynchronously
 */
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

/**
 * Converts Hex color string (#ffffff or #fff) to RGB array [r, g, b]
 */
export function hexToRgb(hex: string): [number, number, number] {
  let cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map((c) => c + c).join('');
  }
  const num = parseInt(cleanHex, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

/**
 * Calculates Euclidean color distance in RGB space
 */
function colorDistance(
  r1: number,
  g1: number,
  b1: number,
  r2: number,
  g2: number,
  b2: number
): number {
  return Math.sqrt(
    (r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2) + (b1 - b2) * (b1 - b2)
  );
}

/**
 * Perform 100% Client-Side Background Removal via Smart Adaptive Chroma Key & Edge Smoothing
 */
export async function processBackgroundRemoval(
  imgSource: HTMLImageElement | string,
  settings: BgRemovalSettings
): Promise<string> {
  const img = typeof imgSource === 'string' ? await loadImage(imgSource) : imgSource;
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Could not create canvas context');

  // Draw original image
  ctx.drawImage(img, 0, 0);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  const totalPixels = canvas.width * canvas.height;

  let targetR = 255;
  let targetG = 255;
  let targetB = 255;

  if (settings.mode === 'chroma') {
    [targetR, targetG, targetB] = hexToRgb(settings.chromaColor);
  } else {
    // Auto Mode: Sample 4 corners to detect dominant background color
    const cornerSamples: [number, number, number][] = [];
    const sampleSize = Math.min(10, Math.floor(canvas.width / 10));

    // Sample top-left, top-right, bottom-left, bottom-right
    for (let x = 0; x < sampleSize; x++) {
      for (let y = 0; y < sampleSize; y++) {
        // TL
        let idx = (y * canvas.width + x) * 4;
        cornerSamples.push([data[idx], data[idx + 1], data[idx + 2]]);
        // TR
        idx = (y * canvas.width + (canvas.width - 1 - x)) * 4;
        cornerSamples.push([data[idx], data[idx + 1], data[idx + 2]]);
        // BL
        idx = ((canvas.height - 1 - y) * canvas.width + x) * 4;
        cornerSamples.push([data[idx], data[idx + 1], data[idx + 2]]);
        // BR
        idx = ((canvas.height - 1 - y) * canvas.width + (canvas.width - 1 - x)) * 4;
        cornerSamples.push([data[idx], data[idx + 1], data[idx + 2]]);
      }
    }

    // Average corner colors
    let sumR = 0, sumG = 0, sumB = 0;
    cornerSamples.forEach(([r, g, b]) => {
      sumR += r;
      sumG += g;
      sumB += b;
    });
    targetR = Math.round(sumR / cornerSamples.length);
    targetG = Math.round(sumG / cornerSamples.length);
    targetB = Math.round(sumB / cornerSamples.length);
  }

  // Max distance in RGB space is ~441.67
  const maxToleranceDistance = (settings.tolerance / 100) * 220; // range ~0-220
  const featherRange = settings.feather; // range 0-20

  for (let i = 0; i < totalPixels * 4; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const dist = colorDistance(r, g, b, targetR, targetG, targetB);

    if (dist < maxToleranceDistance) {
      if (featherRange > 0 && dist > maxToleranceDistance - featherRange) {
        // Soft alpha transition
        const alphaRatio = (dist - (maxToleranceDistance - featherRange)) / featherRange;
        data[i + 3] = Math.round(data[i + 3] * alphaRatio);
      } else {
        // Fully transparent
        data[i + 3] = 0;
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);

  // If user selected background replacement (solid, gradient, blur)
  if (settings.bgReplacement !== 'transparent') {
    const bgCanvas = document.createElement('canvas');
    bgCanvas.width = canvas.width;
    bgCanvas.height = canvas.height;
    const bgCtx = bgCanvas.getContext('2d');

    if (bgCtx) {
      if (settings.bgReplacement === 'solid') {
        bgCtx.fillStyle = settings.solidBgColor;
        bgCtx.fillRect(0, 0, bgCanvas.width, bgCanvas.height);
      } else if (settings.bgReplacement === 'gradient') {
        const grad = bgCtx.createLinearGradient(0, 0, bgCanvas.width, bgCanvas.height);
        if (settings.gradientBg === 'sunset') {
          grad.addColorStop(0, '#ff7e5f');
          grad.addColorStop(1, '#feb47b');
        } else if (settings.gradientBg === 'ocean') {
          grad.addColorStop(0, '#2b5876');
          grad.addColorStop(1, '#4e4376');
        } else if (settings.gradientBg === 'neon') {
          grad.addColorStop(0, '#00f2fe');
          grad.addColorStop(1, '#4facfe');
        } else {
          grad.addColorStop(0, '#667eea');
          grad.addColorStop(1, '#764ba2');
        }
        bgCtx.fillStyle = grad;
        bgCtx.fillRect(0, 0, bgCanvas.width, bgCanvas.height);
      } else if (settings.bgReplacement === 'blur') {
        bgCtx.filter = 'blur(20px)';
        bgCtx.drawImage(img, -20, -20, bgCanvas.width + 40, bgCanvas.height + 40);
        bgCtx.filter = 'none';
      }

      // Draw foreground image over replacement canvas
      bgCtx.drawImage(canvas, 0, 0);
      return bgCanvas.toDataURL('image/png');
    }
  }

  return canvas.toDataURL('image/png');
}

/**
 * 100% Client-Side Format Conversion (PNG, JPG, JPEG, WEBP)
 */
export async function convertFormat(
  imgSource: HTMLImageElement | string,
  targetFormat: OutputFormat,
  quality: number = 0.92
): Promise<{ dataUrl: string; sizeBytes: number }> {
  const img = typeof imgSource === 'string' ? await loadImage(imgSource) : imgSource;
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not create canvas context');

  // If converting transparent image to JPG/JPEG, fill background with white
  if (targetFormat === 'jpg' || targetFormat === 'jpeg') {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  ctx.drawImage(img, 0, 0);

  let mimeType = 'image/png';
  if (targetFormat === 'jpeg' || targetFormat === 'jpg') {
    mimeType = 'image/jpeg';
  } else if (targetFormat === 'webp') {
    mimeType = 'image/webp';
  }

  const dataUrl = canvas.toDataURL(mimeType, quality);
  const sizeBytes = Math.round((dataUrl.length * 3) / 4);

  return { dataUrl, sizeBytes };
}

/**
 * Perform Image Resizing, Rotating, Flipping, Cropping, & Filter Adjustments
 */
export async function processResizeAndTransform(
  imgSource: HTMLImageElement | string,
  settings: ResizeSettings
): Promise<string> {
  const img = typeof imgSource === 'string' ? await loadImage(imgSource) : imgSource;
  const origW = img.naturalWidth || img.width;
  const origH = img.naturalHeight || img.height;

  // Compute Target Dimensions
  let targetW = settings.width || origW;
  let targetH = settings.height || origH;

  if (settings.mode === 'percentage') {
    const scale = settings.percentage / 100;
    targetW = Math.round(origW * scale);
    targetH = Math.round(origH * scale);
  }

  // Handle Rotation swap dimensions if 90 or 270 deg
  const isRotated90 = settings.rotation === 90 || settings.rotation === 270;
  const canvasW = isRotated90 ? targetH : targetW;
  const canvasH = isRotated90 ? targetW : targetH;

  const canvas = document.createElement('canvas');
  canvas.width = canvasW;
  canvas.height = canvasH;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not create canvas context');

  // Apply visual adjustments filter string
  const filters: string[] = [];
  if (settings.brightness !== 100) filters.push(`brightness(${settings.brightness}%)`);
  if (settings.contrast !== 100) filters.push(`contrast(${settings.contrast}%)`);
  if (settings.saturation !== 100) filters.push(`saturate(${settings.saturation}%)`);
  if (settings.grayscale) filters.push(`grayscale(100%)`);
  if (settings.sepia) filters.push(`sepia(100%)`);

  if (filters.length > 0) {
    ctx.filter = filters.join(' ');
  }

  // Set transform matrix for rotation & flips
  ctx.save();
  ctx.translate(canvasW / 2, canvasH / 2);

  if (settings.rotation !== 0) {
    ctx.rotate((settings.rotation * Math.PI) / 180);
  }

  ctx.scale(settings.flipH ? -1 : 1, settings.flipV ? -1 : 1);

  // Draw scaled image centered
  ctx.drawImage(img, -targetW / 2, -targetH / 2, targetW, targetH);
  ctx.restore();

  return canvas.toDataURL('image/png');
}

/**
 * Format bytes into human readable KB / MB
 */
export function formatBytes(bytes: number, decimals: number = 2): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
