import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Capacitor } from '@capacitor/core';

export type StorageDirectory = 'downloads' | 'documents' | 'pictures' | 'custom_picker' | 'system_share';

export interface SaveResult {
  success: boolean;
  message: string;
  uri?: string;
}

/**
 * Converts a data URL string into a Blob
 */
export function dataUrlToBlob(dataUrl: string): Blob {
  const arr = dataUrl.split(',');
  const mimeMatch = arr[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const bstr = atob(arr[1] || arr[0]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new Blob([u8arr], { type: mime });
}

/**
 * Converts a Blob to a Data URL string
 */
export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(blob);
  });
}

/**
 * Checks and requests storage permissions on native devices (Android / iOS).
 * Triggers native system permission pop-up if not already granted.
 */
export async function requestStoragePermissions(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) {
    return true;
  }

  try {
    const status = await Filesystem.checkPermissions();
    if (status.publicStorage === 'granted') {
      return true;
    }

    const requestResult = await Filesystem.requestPermissions();
    return requestResult.publicStorage === 'granted';
  } catch (err) {
    console.warn('Storage permission request skipped or not required:', err);
    return true;
  }
}

/**
 * Saves a file to the specified location on the device storage.
 */
export async function saveFileWithLocationOption(
  data: string | Blob,
  filename: string,
  location: StorageDirectory = 'downloads',
  mimeType?: string
): Promise<SaveResult> {
  try {
    await requestStoragePermissions();

    const blob = data instanceof Blob ? data : dataUrlToBlob(data);
    const dataUrl = data instanceof Blob ? await blobToDataUrl(data) : data;
    const base64Data = dataUrl.includes(',') ? dataUrl.split(',')[1] : dataUrl;
    const fileMime = mimeType || blob.type || 'application/octet-stream';

    // 1. Custom System File Picker (native OS folder chooser dialog)
    if (location === 'custom_picker') {
      if (typeof window !== 'undefined' && 'showSaveFilePicker' in window) {
        try {
          const ext = filename.split('.').pop() || '';
          const handle = await (window as any).showSaveFilePicker({
            suggestedName: filename,
            types: [
              {
                description: 'File',
                accept: { [fileMime]: [`.${ext}`] },
              },
            ],
          });
          const writable = await handle.createWritable();
          await writable.write(blob);
          await writable.close();
          return {
            success: true,
            message: `Saved to chosen location: ${handle.name || filename}`,
          };
        } catch (pickerErr: any) {
          if (pickerErr.name === 'AbortError') {
            return { success: false, message: 'Save cancelled by user' };
          }
          console.warn('System file picker failed, falling back:', pickerErr);
        }
      }
    }

    // 2. Save & Share Sheet (Drive / Files app / Bluetooth / Messaging)
    if (location === 'system_share') {
      const isNative = Capacitor.isNativePlatform();
      let fileUri = '';

      if (isNative) {
        try {
          const fileResult = await Filesystem.writeFile({
            path: filename,
            data: base64Data,
            directory: Directory.Cache,
            recursive: true,
          });
          fileUri = fileResult.uri;
        } catch (e) {
          console.error('Cache write failed:', e);
        }
      }

      if (fileUri) {
        try {
          await Share.share({
            title: filename,
            text: `Image Studio - ${filename}`,
            url: fileUri,
            dialogTitle: `Save or Share ${filename}`,
          });
          return {
            success: true,
            message: `Saved / Prompted via System Share (${filename})`,
            uri: fileUri,
          };
        } catch (shareErr) {
          console.log('Share dismissed:', shareErr);
        }
      } else if (typeof navigator !== 'undefined' && navigator.canShare) {
        const file = new File([blob], filename, { type: fileMime });
        if (navigator.canShare({ files: [file] })) {
          try {
            await navigator.share({
              files: [file],
              title: filename,
            });
            return {
              success: true,
              message: `Saved via System Dialog (${filename})`,
            };
          } catch (e) {
            console.log('Web share cancelled:', e);
          }
        }
      }
    }

    // 3. Native Storage Directories (Documents / Pictures / Downloads)
    const isNative = Capacitor.isNativePlatform();
    let savedNativePath = '';

    if (isNative) {
      let targetDir = Directory.Documents;
      if (location === 'downloads') {
        targetDir = Directory.Documents;
      } else if (location === 'pictures') {
        targetDir = Directory.Documents;
      } else if (location === 'documents') {
        targetDir = Directory.Documents;
      }

      try {
        const fileResult = await Filesystem.writeFile({
          path: filename,
          data: base64Data,
          directory: targetDir,
          recursive: true,
        });
        savedNativePath = fileResult.uri;
        console.log('Successfully saved native file to:', fileResult.uri);
      } catch (docErr) {
        console.warn('Failed to write to primary directory, fallback to Cache:', docErr);
        try {
          const cacheResult = await Filesystem.writeFile({
            path: filename,
            data: base64Data,
            directory: Directory.Cache,
            recursive: true,
          });
          savedNativePath = cacheResult.uri;
        } catch (cacheErr) {
          console.error('Failed to write file natively:', cacheErr);
        }
      }
    }

    // Direct Browser Download to local Downloads
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      URL.revokeObjectURL(objectUrl);
    }, 3000);

    const locationNameMap: Record<StorageDirectory, string> = {
      downloads: 'Downloads Folder',
      documents: 'Documents Storage',
      pictures: 'Pictures Storage',
      custom_picker: 'Custom Location',
      system_share: 'System Storage',
    };

    return {
      success: true,
      message: `File saved to ${locationNameMap[location]} (${filename})`,
      uri: savedNativePath || undefined,
    };
  } catch (err: any) {
    console.error('saveFileWithLocationOption error:', err);
    return {
      success: false,
      message: err.message || 'Failed to save file',
    };
  }
}

/**
 * Backward compatible wrapper
 */
export async function saveFileToDevice(
  data: string | Blob,
  filename: string,
  mimeType?: string
): Promise<SaveResult> {
  return saveFileWithLocationOption(data, filename, 'downloads', mimeType);
}

