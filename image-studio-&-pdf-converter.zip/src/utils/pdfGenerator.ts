import { jsPDF } from 'jspdf';
import { ImageFile, PdfSettings } from '../types';
import { loadImage } from './imageProcessing';

export async function generatePdfFromImages(
  images: ImageFile[],
  settings: PdfSettings
): Promise<Blob> {
  if (images.length === 0) {
    throw new Error('No images selected for PDF creation');
  }

  // Determine initial page configuration
  let doc: jsPDF | null = null;

  for (let index = 0; index < images.length; index++) {
    const imgItem = images[index];
    const imgSrc = imgItem.processedUrl || imgItem.dataUrl;
    const img = await loadImage(imgSrc);

    const origW = img.naturalWidth || img.width;
    const origH = img.naturalHeight || img.height;

    // Determine Orientation
    let orientation: 'p' | 'l' = 'p';
    if (settings.orientation === 'landscape') {
      orientation = 'l';
    } else if (settings.orientation === 'auto') {
      orientation = origW > origH ? 'l' : 'p';
    } else {
      orientation = 'p';
    }

    // Determine Page dimensions (in mm)
    let pageWidthMm = 210; // A4 portrait width
    let pageHeightMm = 297; // A4 portrait height

    if (settings.pageSize === 'letter') {
      pageWidthMm = 215.9;
      pageHeightMm = 279.4;
    } else if (settings.pageSize === 'fit') {
      // Fit page size directly to image aspect ratio (1 px ~ 0.264583 mm)
      pageWidthMm = origW * 0.264583;
      pageHeightMm = origH * 0.264583;
    }

    if (orientation === 'l' && settings.pageSize !== 'fit') {
      const temp = pageWidthMm;
      pageWidthMm = pageHeightMm;
      pageHeightMm = temp;
    }

    // Margins (in mm)
    let marginMm = 0;
    if (settings.margin === 'small') marginMm = 10;
    if (settings.margin === 'large') marginMm = 20;

    const printableW = pageWidthMm - marginMm * 2;
    const printableH = pageHeightMm - marginMm * 2;

    // Calculate aspect ratio scaling inside printable area
    const scale = Math.min(printableW / origW, printableH / origH);
    const drawW = origW * scale;
    const drawH = origH * scale;

    // Center image on page
    const xPos = marginMm + (printableW - drawW) / 2;
    const yPos = marginMm + (printableH - drawH) / 2;

    // Initialize document or add new page
    if (!doc) {
      doc = new jsPDF({
        orientation,
        unit: 'mm',
        format: settings.pageSize === 'fit' ? [pageWidthMm, pageHeightMm] : settings.pageSize,
      });
    } else {
      doc.addPage(
        settings.pageSize === 'fit' ? [pageWidthMm, pageHeightMm] : settings.pageSize,
        orientation
      );
    }

    // Prepare compressed JPEG or PNG data string for jsPDF
    const format = imgItem.type.includes('png') ? 'PNG' : 'JPEG';
    doc.addImage(imgSrc, format, xPos, yPos, drawW, drawH, undefined, 'FAST');
  }

  if (!doc) {
    throw new Error('Failed to generate PDF document');
  }

  return doc.output('blob');
}
