import React from 'react';
import { Lock, Cpu, EyeOff, Zap } from 'lucide-react';

export const PrivacyBanner: React.FC = () => {
  return (
    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 my-4 max-w-4xl mx-auto text-emerald-900 dark:text-emerald-200">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-emerald-500/20 rounded-xl text-emerald-600 dark:text-emerald-400 shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm tracking-tight">100% Local Device Security & Offline Performance</h3>
            <p className="text-xs opacity-90 leading-relaxed">
              Your photos never leave your device. All background removal, PDF creation, and conversions run locally in WebAssembly & HTML5 Canvas.
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3 text-xs font-semibold shrink-0 bg-white/60 dark:bg-slate-900/60 px-3 py-1.5 rounded-xl border border-emerald-500/30">
          <span className="flex items-center gap-1 text-slate-700 dark:text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-blue-500" /> Web GPU/Canvas
          </span>
          <span className="flex items-center gap-1 text-slate-700 dark:text-slate-300">
            <EyeOff className="w-3.5 h-3.5 text-emerald-500" /> Ad-Free
          </span>
          <span className="flex items-center gap-1 text-slate-700 dark:text-slate-300">
            <Zap className="w-3.5 h-3.5 text-amber-500" /> Instant
          </span>
        </div>
      </div>
    </div>
  );
};
