import React, { useState, useEffect } from 'react';
import { ImageFile, ResizeSettings } from '../types';
import { processResizeAndTransform, formatBytes } from '../utils/imageProcessing';
import { Scaling, RotateCw, FlipHorizontal, FlipVertical, Sliders, Download, X, RefreshCw, Sun, Crop, CheckCircle2 } from 'lucide-react';
import { SaveLocationModal } from './SaveLocationModal';
import { SaveResult } from '../utils/fileSaver';

interface ImageResizerProps {
  image: ImageFile | null;
  onClearImage: () => void;
}

export const ImageResizer: React.FC<ImageResizerProps> = ({ image, onClearImage }) => {
  const [settings, setSettings] = useState<ResizeSettings>({
    mode: 'dimensions',
    width: image?.width || 800,
    height: image?.height || 800,
    maintainAspectRatio: true,
    percentage: 100,
    rotation: 0,
    flipH: false,
    flipV: false,
    brightness: 100,
    contrast: 100,
    saturation: 100,
    grayscale: false,
    sepia: false,
  });

  const [processedUrl, setProcessedUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (!image) return;

    let isMounted = true;
    setIsProcessing(true);

    const timer = setTimeout(async () => {
      try {
        const res = await processResizeAndTransform(image.dataUrl, settings);
        if (isMounted) setProcessedUrl(res);
      } catch (err) {
        console.error('Resize/Transform Error:', err);
      } finally {
        if (isMounted) setIsProcessing(false);
      }
    }, 100);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [image, settings]);

  if (!image) return null;

  const baseName = image.name.substring(0, image.name.lastIndexOf('.')) || image.name;
  const defaultFilename = `${baseName}_resized.png`;

  const handleSaveComplete = (result: SaveResult) => {
    setSaveMessage(result.message);
    setTimeout(() => setSaveMessage(null), 4000);
  };

  const handleWidthChange = (val: number) => {
    if (settings.maintainAspectRatio && image.width > 0) {
      const ratio = image.height / image.width;
      setSettings({
        ...settings,
        width: val,
        height: Math.round(val * ratio),
      });
    } else {
      setSettings({ ...settings, width: val });
    }
  };

  const handleHeightChange = (val: number) => {
    if (settings.maintainAspectRatio && image.height > 0) {
      const ratio = image.width / image.height;
      setSettings({
        ...settings,
        height: val,
        width: Math.round(val * ratio),
      });
    } else {
      setSettings({ ...settings, height: val });
    }
  };

  const handleRotate = () => {
    setSettings((prev) => ({
      ...prev,
      rotation: (prev.rotation + 90) % 360,
    }));
  };

  return (
    <div className="w-full space-y-6">
      <SaveLocationModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        data={processedUrl}
        defaultFilename={defaultFilename}
        mimeType="image/png"
        onSaveComplete={handleSaveComplete}
      />

      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center space-x-3">
          <button
            onClick={onClearImage}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white truncate max-w-xs sm:max-w-md">
              {image.name}
            </h2>
            <p className="text-xs text-slate-500">
              Original: {image.width} × {image.height} px
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSaveModalOpen(true)}
          disabled={!processedUrl || isProcessing}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm px-6 py-2.5 rounded-xl shadow-md transition-all disabled:opacity-50 active:scale-95"
        >
          <Download className="w-4 h-4" />
          <span>Save Resized Image</span>
        </button>
      </div>

      {saveMessage && (
        <div className="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3.5 rounded-xl text-sm font-medium animate-in fade-in slide-in-from-top-1 duration-200">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>{saveMessage}</span>
        </div>
      )}

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Preview Canvas */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative w-full h-[380px] sm:h-[460px] rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 flex items-center justify-center p-4">
            {isProcessing && (
              <div className="absolute inset-0 z-20 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center text-white">
                <RefreshCw className="w-8 h-8 animate-spin text-blue-400" />
              </div>
            )}

            <img
              src={processedUrl || image.dataUrl}
              alt="Resized"
              className="max-h-full max-w-full object-contain rounded-lg"
            />
          </div>

          {/* Dimension status card */}
          <div className="flex flex-wrap items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
            <div>
              Target Size:{' '}
              <span className="font-bold text-slate-900 dark:text-white">
                {settings.width} × {settings.height} px
              </span>
            </div>
            <div>
              Rotation:{' '}
              <span className="font-bold text-slate-900 dark:text-white">{settings.rotation}°</span>
            </div>
            <div>
              Scale:{' '}
              <span className="font-bold text-slate-900 dark:text-white">
                {Math.round((settings.width / image.width) * 100)}%
              </span>
            </div>
          </div>
        </div>

        {/* Right: Controls & Adjustments */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-5 shadow-sm">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
            <Scaling className="w-4 h-4 text-blue-500" /> Dimension Controls
          </h3>

          {/* Quick Preset Buttons */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Quick Scaling Presets
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[25, 50, 75, 200].map((pct) => (
                <button
                  key={pct}
                  onClick={() => {
                    const w = Math.round((image.width * pct) / 100);
                    const h = Math.round((image.height * pct) / 100);
                    setSettings({ ...settings, width: w, height: h });
                  }}
                  className="py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-lg transition-colors"
                >
                  {pct}%
                </button>
              ))}
            </div>
          </div>

          {/* Manual Width & Height */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Width (px)
              </label>
              <input
                type="number"
                value={settings.width}
                onChange={(e) => handleWidthChange(Number(e.target.value))}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Height (px)
              </label>
              <input
                type="number"
                value={settings.height}
                onChange={(e) => handleHeightChange(Number(e.target.value))}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <label className="flex items-center space-x-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.maintainAspectRatio}
              onChange={(e) => setSettings({ ...settings, maintainAspectRatio: e.target.checked })}
              className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
            <span>Lock Aspect Ratio</span>
          </label>

          {/* Rotation & Flips */}
          <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              Orientation & Transform
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleRotate}
                className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl flex items-center justify-center space-x-1"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>Rotate</span>
              </button>
              <button
                onClick={() => setSettings({ ...settings, flipH: !settings.flipH })}
                className={`p-2 text-xs font-bold rounded-xl flex items-center justify-center space-x-1 ${
                  settings.flipH
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
                }`}
              >
                <FlipHorizontal className="w-3.5 h-3.5" />
                <span>Flip H</span>
              </button>
              <button
                onClick={() => setSettings({ ...settings, flipV: !settings.flipV })}
                className={`p-2 text-xs font-bold rounded-xl flex items-center justify-center space-x-1 ${
                  settings.flipV
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
                }`}
              >
                <FlipVertical className="w-3.5 h-3.5" />
                <span>Flip V</span>
              </button>
            </div>
          </div>

          {/* Adjustments: Brightness & Contrast */}
          <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-3">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-amber-500" /> Color Enhancements
            </label>

            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-400">
                <span>Brightness</span>
                <span>{settings.brightness}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="150"
                value={settings.brightness}
                onChange={(e) => setSettings({ ...settings, brightness: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-400">
                <span>Contrast</span>
                <span>{settings.contrast}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="150"
                value={settings.contrast}
                onChange={(e) => setSettings({ ...settings, contrast: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setSettings({ ...settings, grayscale: !settings.grayscale })}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg border ${
                  settings.grayscale
                    ? 'bg-slate-800 text-white border-slate-800'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                Grayscale
              </button>
              <button
                onClick={() => setSettings({ ...settings, sepia: !settings.sepia })}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg border ${
                  settings.sepia
                    ? 'bg-amber-800 text-white border-amber-800'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                Sepia
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
