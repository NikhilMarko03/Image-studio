import React, { useRef } from 'react';
import { Upload, Image as ImageIcon, Camera, Sparkles, FileText, User } from 'lucide-react';
import { ImageFile } from '../types';
import { createSampleProductImage, createSamplePortraitImage, createSampleDocumentImage } from '../utils/sampleImages';

interface ImageUploaderProps {
  onImageSelected: (image: ImageFile) => void;
  onMultipleImagesSelected?: (images: ImageFile[]) => void;
  allowMultiple?: boolean;
  title?: string;
  subtitle?: string;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  onImageSelected,
  onMultipleImagesSelected,
  allowMultiple = false,
  title = 'Upload or Select Image',
  subtitle = 'Drag & drop, browse files, or pick a sample photo to test',
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File): Promise<ImageFile> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        const img = new Image();
        img.onload = () => {
          resolve({
            id: Math.random().toString(36).substring(2, 9),
            name: file.name,
            type: file.type || 'image/png',
            size: file.size,
            width: img.width,
            height: img.height,
            dataUrl,
            file,
          });
        };
        img.src = dataUrl;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const filesArray = Array.from<File>(e.target.files);

    if (allowMultiple && onMultipleImagesSelected) {
      const processed = await Promise.all(filesArray.map(processFile));
      onMultipleImagesSelected(processed);
    } else {
      const single = await processFile(filesArray[0]);
      onImageSelected(single);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!e.dataTransfer.files || e.dataTransfer.files.length === 0) return;
    const filesArray = Array.from<File>(e.dataTransfer.files).filter((f: File) => f.type.startsWith('image/'));
    if (filesArray.length === 0) return;

    if (allowMultiple && onMultipleImagesSelected) {
      const processed = await Promise.all(filesArray.map(processFile));
      onMultipleImagesSelected(processed);
    } else {
      const single = await processFile(filesArray[0]);
      onImageSelected(single);
    }
  };

  const loadSample = (type: 'product' | 'portrait' | 'document') => {
    let dataUrl = '';
    let name = 'sample.png';
    if (type === 'product') {
      dataUrl = createSampleProductImage();
      name = 'product_camera_studio.png';
    } else if (type === 'portrait') {
      dataUrl = createSamplePortraitImage();
      name = 'portrait_greenscreen.jpg';
    } else {
      dataUrl = createSampleDocumentImage();
      name = 'invoice_document.jpg';
    }

    const img = new Image();
    img.onload = () => {
      onImageSelected({
        id: Math.random().toString(36).substring(2, 9),
        name,
        type: type === 'portrait' || type === 'document' ? 'image/jpeg' : 'image/png',
        size: Math.round((dataUrl.length * 3) / 4),
        width: img.width,
        height: img.height,
        dataUrl,
      });
    };
    img.src = dataUrl;
  };

  return (
    <div className="w-full">
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className="group relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-400 bg-white dark:bg-slate-900/60 rounded-3xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-300 shadow-sm hover:shadow-md"
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          multiple={allowMultiple}
          className="hidden"
        />

        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
          <Upload className="w-8 h-8" />
        </div>

        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{title}</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6">{subtitle}</p>

        <div className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm py-2.5 px-6 rounded-xl shadow-md transition-colors">
          <Camera className="w-4 h-4" />
          <span>Select From Device</span>
        </div>
      </div>

      {/* Quick Try Samples */}
      <div className="mt-6">
        <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-center mb-3">
          Or test instantly with a built-in sample
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={() => loadSample('product')}
            className="flex items-center space-x-3 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-400 transition-all text-left group"
          >
            <div className="p-2.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-900 dark:text-white">Studio Product</div>
              <div className="text-xs text-slate-500">Camera studio shot</div>
            </div>
          </button>

          <button
            onClick={() => loadSample('portrait')}
            className="flex items-center space-x-3 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-400 transition-all text-left group"
          >
            <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 group-hover:scale-105 transition-transform">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-900 dark:text-white">Portrait / Chroma</div>
              <div className="text-xs text-slate-500">Green screen photo</div>
            </div>
          </button>

          <button
            onClick={() => loadSample('document')}
            className="flex items-center space-x-3 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-500 dark:hover:border-amber-400 transition-all text-left group"
          >
            <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 group-hover:scale-105 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-900 dark:text-white">Invoice Document</div>
              <div className="text-xs text-slate-500">Paper scan for PDF</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
