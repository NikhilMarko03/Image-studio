import React from 'react';
import { X, ShieldCheck, Lock, WifiOff, Scissors, RefreshCw, FileText, Scaling, Sparkles } from 'lucide-react';

interface GuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GuideModal: React.FC<GuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3">
          <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-600 dark:text-blue-400">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              ImageStudio Pro Guide & Privacy
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Ad-Free • Offline-First • 100% Local Processing
            </p>
          </div>
        </div>

        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl space-y-2 text-xs text-emerald-900 dark:text-emerald-200">
          <div className="flex items-center space-x-2 font-bold text-sm">
            <Lock className="w-4 h-4 text-emerald-500" />
            <span>Maximum Privacy Guarantee</span>
          </div>
          <p className="leading-relaxed opacity-90">
            This app uses client-side HTML5 Canvas and WebAssembly. Your photos stay strictly inside your device browser memory. No images, metadata, or metrics are ever uploaded to any cloud server or third party.
          </p>
        </div>

        <div className="space-y-4 text-xs text-slate-600 dark:text-slate-300">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white uppercase tracking-wider">
            Features & Capabilities
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
              <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-white text-xs">
                <Scissors className="w-4 h-4 text-blue-500" />
                <span>Background Remover</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Auto-detects backgrounds or lets you pick chroma key colors. Replace transparent cutouts with solid colors, gradients, or blurred backdrops.
              </p>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
              <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-white text-xs">
                <RefreshCw className="w-4 h-4 text-emerald-500" />
                <span>Format Converter</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Convert photos between JPG, JPEG, PNG, and WebP instantly with real-time compression quality and file size reduction preview.
              </p>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
              <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-white text-xs">
                <FileText className="w-4 h-4 text-indigo-500" />
                <span>Image to PDF</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Merge single or multiple photos into a crisp PDF. Reorder pages, customize page size (A4, Letter, Fit), margins, and orientation.
              </p>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
              <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-white text-xs">
                <Scaling className="w-4 h-4 text-amber-500" />
                <span>Resize & Edit</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Scale dimensions with aspect ratio lock, rotate, flip horizontally/vertically, and fine-tune brightness, contrast, and color filters.
              </p>
            </div>
          </div>
        </div>

        {/* Offline App Installation Instructions */}
        <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl space-y-3 text-xs text-slate-700 dark:text-slate-300">
          <div className="flex items-center space-x-2 font-bold text-sm text-blue-600 dark:text-blue-400">
            <WifiOff className="w-4 h-4" />
            <span>How to Install & Run Offline on Your Device</span>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
            You can install this app directly onto your mobile phone or computer home screen so it works <strong>100% offline without any internet connection</strong>:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
            <div className="bg-white/80 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <p className="font-bold text-slate-900 dark:text-white mb-1">📱 Android / Chrome:</p>
              <p className="text-slate-500 dark:text-slate-400">Tap the 3 dots (⋮) menu in Chrome & select <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>.</p>
            </div>
            <div className="bg-white/80 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <p className="font-bold text-slate-900 dark:text-white mb-1">🍎 iPhone / Safari:</p>
              <p className="text-slate-500 dark:text-slate-400">Tap the Share icon (↑) in Safari & select <strong>"Add to Home Screen"</strong>.</p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow-md transition-colors text-sm"
        >
          Got It, Let's Get Started
        </button>
      </div>
    </div>
  );
};
