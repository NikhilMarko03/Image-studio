import React, { useState, useEffect, useRef } from 'react';
import { ImageFile, BgRemovalSettings } from '../types';
import { processBackgroundRemoval, formatBytes } from '../utils/imageProcessing';
import { Download, Sliders, Pipette, RefreshCw, Layers, Check, Sparkles, Eye, ArrowRight, X, CheckCircle2 } from 'lucide-react';
import { SaveLocationModal } from './SaveLocationModal';
import { SaveResult } from '../utils/fileSaver';

interface BackgroundRemoverProps {
  image: ImageFile | null;
  onClearImage: () => void;
}

export const BackgroundRemover: React.FC<BackgroundRemoverProps> = ({ image, onClearImage }) => {
  const [settings, setSettings] = useState<BgRemovalSettings>({
    mode: 'auto',
    tolerance: 45,
    feather: 8,
    chromaColor: '#10b981', // default green
    brushSize: 30,
    brushMode: 'erase',
    bgReplacement: 'transparent',
    solidBgColor: '#ffffff',
    gradientBg: 'sunset',
  });

  const [processedUrl, setProcessedUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [compareMode, setCompareMode] = useState<'split' | 'toggle'>('split');
  const [splitPos, setSplitPos] = useState<number>(50);
  const [showOriginal, setShowOriginal] = useState<boolean>(false);
  const [downloadFormat, setDownloadFormat] = useState<'png' | 'webp'>('png');
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Trigger background removal when settings or image change
  useEffect(() => {
    if (!image) return;

    let isMounted = true;
    setIsProcessing(true);

    const timer = setTimeout(async () => {
      try {
        const result = await processBackgroundRemoval(image.dataUrl, settings);
        if (isMounted) {
          setProcessedUrl(result);
        }
      } catch (err) {
        console.error('BG removal failed:', err);
      } finally {
        if (isMounted) setIsProcessing(false);
      }
    }, 120);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [image, settings]);

  if (!image) return null;

  const baseName = image.name.substring(0, image.name.lastIndexOf('.')) || image.name;
  const defaultFilename = `${baseName}_no_bg.${downloadFormat}`;
  const mimeType = downloadFormat === 'png' ? 'image/png' : 'image/webp';

  const handleSaveComplete = (result: SaveResult) => {
    setSaveMessage(result.message);
    setTimeout(() => setSaveMessage(null), 4000);
  };

  return (
    <div className="w-full space-y-6">
      <SaveLocationModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        data={processedUrl}
        defaultFilename={defaultFilename}
        mimeType={mimeType}
        onSaveComplete={handleSaveComplete}
      />

      {/* Top Controls Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center space-x-3">
          <button
            onClick={onClearImage}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Change Image"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white truncate max-w-xs sm:max-w-md">
              {image.name}
            </h2>
            <p className="text-xs text-slate-500">
              {image.width} × {image.height} px • {formatBytes(image.size)}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={downloadFormat}
            onChange={(e) => setDownloadFormat(e.target.value as 'png' | 'webp')}
            className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 outline-none"
          >
            <option value="png">PNG (Transparent)</option>
            <option value="webp">WebP (High Speed)</option>
          </select>

          <button
            onClick={() => setIsSaveModalOpen(true)}
            disabled={!processedUrl || isProcessing}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm px-5 py-2.5 rounded-xl shadow-md transition-all disabled:opacity-50 active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Save Result</span>
          </button>
        </div>
      </div>

      {saveMessage && (
        <div className="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3.5 rounded-xl text-sm font-medium animate-in fade-in slide-in-from-top-1 duration-200">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>{saveMessage}</span>
        </div>
      )}

      {/* Main Grid: Preview Canvas + Adjustments Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual Preview Canvas */}
        <div className="lg:col-span-8 flex flex-col space-y-4">
          <div className="relative w-full h-[400px] sm:h-[500px] rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 flex items-center justify-center group shadow-inner">
            {/* Checkerboard Background for transparency */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                  'radial-gradient(#94a3b8 1px, transparent 1px), radial-gradient(#94a3b8 1px, #0f172a 1px)',
                backgroundSize: '20px 20px',
                backgroundPosition: '0 0, 10px 10px',
              }}
            />

            {/* Spinner Overlay during processing */}
            {isProcessing && (
              <div className="absolute inset-0 z-20 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center text-white">
                <div className="flex items-center space-x-3 bg-slate-900 px-5 py-3 rounded-2xl border border-slate-700 shadow-xl">
                  <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
                  <span className="text-sm font-semibold">Removing Background...</span>
                </div>
              </div>
            )}

            {/* Comparison view */}
            {compareMode === 'split' && processedUrl ? (
              <div className="relative w-full h-full flex items-center justify-center select-none overflow-hidden">
                {/* Background (Processed) */}
                <img
                  src={processedUrl}
                  alt="Processed"
                  className="max-h-full max-w-full object-contain pointer-events-none"
                />

                {/* Foreground (Original clipped by slider position) */}
                <div
                  className="absolute inset-0 overflow-hidden"
                  style={{ width: `${splitPos}%` }}
                >
                  <img
                    src={image.dataUrl}
                    alt="Original"
                    className="max-h-full max-w-full object-contain pointer-events-none"
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'contain',
                    }}
                  />
                </div>

                {/* Divider Line */}
                <div
                  className="absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_10px_rgba(0,0,0,0.5)] z-10 cursor-ew-resize"
                  style={{ left: `${splitPos}%` }}
                >
                  <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white text-slate-800 shadow-lg flex items-center justify-center font-bold text-xs">
                    ↔
                  </div>
                </div>

                {/* Invisible Slider input overlay */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={splitPos}
                  onChange={(e) => setSplitPos(Number(e.target.value))}
                  className="absolute inset-0 opacity-0 cursor-ew-resize z-20 w-full h-full"
                />
              </div>
            ) : (
              <img
                src={showOriginal ? image.dataUrl : processedUrl || image.dataUrl}
                alt="Preview"
                className="max-h-full max-w-full object-contain z-10 transition-all duration-200"
              />
            )}

            {/* Canvas Badge */}
            <div className="absolute bottom-4 left-4 z-20 flex items-center space-x-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/80 text-xs text-white">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{showOriginal ? 'Original Image' : 'Background Removed'}</span>
            </div>
          </div>

          {/* Visual Toolbar under canvas */}
          <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <div className="flex items-center space-x-2">
              <span className="text-slate-500 font-medium">Compare Mode:</span>
              <button
                onClick={() => setCompareMode('split')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  compareMode === 'split'
                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                }`}
              >
                Split Slider
              </button>
              <button
                onClick={() => setCompareMode('toggle')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  compareMode === 'toggle'
                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                }`}
              >
                Toggle Mode
              </button>
            </div>

            {compareMode === 'toggle' && (
              <button
                onMouseDown={() => setShowOriginal(true)}
                onMouseUp={() => setShowOriginal(false)}
                onTouchStart={() => setShowOriginal(true)}
                onTouchEnd={() => setShowOriginal(false)}
                className="flex items-center space-x-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold px-3 py-1.5 rounded-lg transition-colors select-none"
              >
                <Eye className="w-4 h-4" />
                <span>Hold to View Original</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Column: Settings Panel */}
        <div className="lg:col-span-4 space-y-5 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-500" /> Cutout & Sensitivity
            </h3>
            <span className="text-xs px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-semibold">
              On-Device
            </span>
          </div>

          {/* Mode Selection */}
          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
              Removal Algorithm
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSettings({ ...settings, mode: 'auto' })}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 border transition-all ${
                  settings.mode === 'auto'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Smart Auto</span>
              </button>

              <button
                onClick={() => setSettings({ ...settings, mode: 'chroma' })}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 border transition-all ${
                  settings.mode === 'chroma'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                <Pipette className="w-3.5 h-3.5" />
                <span>Color Key</span>
              </button>
            </div>
          </div>

          {/* Chroma Key Color Selector if chroma mode */}
          {settings.mode === 'chroma' && (
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span>Background Color Target</span>
                <span className="font-mono text-xs">{settings.chromaColor}</span>
              </label>
              <div className="flex items-center space-x-3">
                <input
                  type="color"
                  value={settings.chromaColor}
                  onChange={(e) => setSettings({ ...settings, chromaColor: e.target.value })}
                  className="w-10 h-10 rounded-xl cursor-pointer border-0 p-0 overflow-hidden bg-transparent"
                />
                <div className="flex gap-1.5 flex-1">
                  {['#10b981', '#3b82f6', '#ffffff', '#000000', '#ef4444'].map((col) => (
                    <button
                      key={col}
                      onClick={() => setSettings({ ...settings, chromaColor: col })}
                      className="w-7 h-7 rounded-lg border border-slate-300 dark:border-slate-600 transition-transform hover:scale-110"
                      style={{ backgroundColor: col }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Sliders: Tolerance */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>Color Tolerance</span>
              <span className="text-blue-600 dark:text-blue-400 font-mono">{settings.tolerance}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="90"
              value={settings.tolerance}
              onChange={(e) => setSettings({ ...settings, tolerance: Number(e.target.value) })}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
          </div>

          {/* Sliders: Feathering Edge */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>Edge Feather / Softness</span>
              <span className="text-blue-600 dark:text-blue-400 font-mono">{settings.feather}px</span>
            </div>
            <input
              type="range"
              min="0"
              max="20"
              value={settings.feather}
              onChange={(e) => setSettings({ ...settings, feather: Number(e.target.value) })}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
          </div>

          {/* Background Replacement Options */}
          <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-3">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-500" /> Background Backdrop
            </label>

            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: 'transparent', label: 'Transparent' },
                  { id: 'solid', label: 'Solid Color' },
                  { id: 'gradient', label: 'Gradient' },
                  { id: 'blur', label: 'Blur Original' },
                ] as const
              ).map((bgOption) => (
                <button
                  key={bgOption.id}
                  onClick={() => setSettings({ ...settings, bgReplacement: bgOption.id })}
                  className={`py-2 px-2.5 rounded-xl text-xs font-semibold transition-all border ${
                    settings.bgReplacement === bgOption.id
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {bgOption.label}
                </button>
              ))}
            </div>

            {/* Options details */}
            {settings.bgReplacement === 'solid' && (
              <div className="flex items-center space-x-3 pt-2">
                <input
                  type="color"
                  value={settings.solidBgColor}
                  onChange={(e) => setSettings({ ...settings, solidBgColor: e.target.value })}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0"
                />
                <span className="text-xs font-mono text-slate-600 dark:text-slate-400">
                  {settings.solidBgColor}
                </span>
              </div>
            )}

            {settings.bgReplacement === 'gradient' && (
              <div className="grid grid-cols-4 gap-2 pt-1">
                {[
                  { id: 'sunset', name: 'Sunset', class: 'from-orange-400 to-pink-500' },
                  { id: 'ocean', name: 'Ocean', class: 'from-blue-600 to-teal-500' },
                  { id: 'neon', name: 'Neon', class: 'from-cyan-400 to-blue-500' },
                  { id: 'lavender', name: 'Purple', class: 'from-indigo-500 to-purple-600' },
                ].map((grad) => (
                  <button
                    key={grad.id}
                    onClick={() => setSettings({ ...settings, gradientBg: grad.id })}
                    className={`h-8 rounded-lg bg-gradient-to-r ${grad.class} border-2 ${
                      settings.gradientBg === grad.id ? 'border-white ring-2 ring-indigo-500' : 'border-transparent'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
