import React from 'react';
import { TabType } from '../types';
import { Scissors, RefreshCw, FileText, Scaling } from 'lucide-react';

interface NavigationProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs: { id: TabType; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      id: 'bg-remover',
      label: 'BG Remover',
      icon: <Scissors className="w-5 h-5" />,
      desc: 'Auto & Chroma Cutout',
    },
    {
      id: 'converter',
      label: 'Format Switch',
      icon: <RefreshCw className="w-5 h-5" />,
      desc: 'JPG, PNG, WEBP',
    },
    {
      id: 'pdf',
      label: 'Image to PDF',
      icon: <FileText className="w-5 h-5" />,
      desc: 'Merge & Export',
    },
    {
      id: 'resize',
      label: 'Resize & Edit',
      icon: <Scaling className="w-5 h-5" />,
      desc: 'Crop, Scale, Adjust',
    },
  ];

  return (
    <div className="w-full bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800 py-3 px-4">
      <div className="max-w-4xl mx-auto">
        <nav className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-200/70 dark:bg-slate-800/80 p-1.5 rounded-2xl">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl transition-all duration-200 text-sm font-semibold ${
                  isActive
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-md shadow-slate-200/50 dark:shadow-none'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/40 dark:hover:bg-slate-700/40'
                }`}
              >
                <span className={isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500'}>
                  {tab.icon}
                </span>
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};
