import React, { useState, useEffect } from 'react';
import { ImageFile, OutputFormat } from '../types';
import { convertFormat, formatBytes } from '../utils/imageProcessing';
import { RefreshCw, Download, ArrowRight, ShieldCheck, X, FileCheck, Sliders, CheckCircle2 } from 'lucide-react';
import { SaveLocationModal } from './SaveLocationModal';
import { SaveResult } from '../utils/fileSaver';

interface FormatConverterProps {
  image: ImageFile | null;
  onClearImage: () => void;
}

export const FormatConverter: React.FC<FormatConverterProps> = ({ image, onClearImage }) => {
  const [targetFormat, setTargetFormat] = useState<OutputFormat>('png');
  const [quality, setQuality] = useState<number>(90);
  const [convertedDataUrl, setConvertedDataUrl] = useState<string | null>(null);
  const [convertedSizeBytes, setConvertedSizeBytes] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (!image) return;

    let isMounted = true;
    setIsProcessing(true);

    const timer = setTimeout(async () => {
      try {
        const res = await convertFormat(image.dataUrl, targetFormat, quality / 100);
        if (isMounted) {
          setConvertedDataUrl(res.dataUrl);
          setConvertedSizeBytes(res.sizeBytes);
        }
      } catch (err) {
        console.error('Format conversion failed:', err);
      } finally {
        if (isMounted) setIsProcessing(false);
      }
    }, 100);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [image, targetFormat, quality]);

  if (!image) return null;

  const currentExt = image.name.split('.').pop()?.toLowerCase() || 'image';
  const baseName = image.name.substring(0, image.name.lastIndexOf('.')) || image.name;
  const defaultFilename = `${baseName}_converted.${targetFormat}`;
  const mimeMap: Record<string, string> = {
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    webp: 'image/webp',
  };

  const handleSaveComplete = (result: SaveResult) => {
    setSaveMessage(result.message);
    setTimeout(() => setSaveMessage(null), 4000);
  };

  const savedBytes = image.size - convertedSizeBytes;
  const savedPercent = Math.round((savedBytes / image.size) * 100);

  return (
    <div className="w-full space-y-6">
      <SaveLocationModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        data={convertedDataUrl}
        defaultFilename={defaultFilename}
        mimeType={mimeMap[targetFormat] || 'image/png'}
        onSaveComplete={handleSaveComplete}
      />

      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center space-x-3">
          <button
            onClick={onClearImage}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white truncate max-w-xs sm:max-w-md">
              {image.name}
            </h2>
            <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
              Current: <span className="text-blue-600 dark:text-blue-400">{currentExt}</span> • {formatBytes(image.size)}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSaveModalOpen(true)}
          disabled={!convertedDataUrl || isProcessing}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm px-6 py-2.5 rounded-xl shadow-md transition-all disabled:opacity-50 active:scale-95"
        >
          <Download className="w-4 h-4" />
          <span>Save as .{targetFormat.toUpperCase()}</span>
        </button>
      </div>

      {saveMessage && (
        <div className="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-3.5 rounded-xl text-sm font-medium animate-in fade-in slide-in-from-top-1 duration-200">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>{saveMessage}</span>
        </div>
      )}

      {/* Grid: Preview & Format Options */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Image Comparison Preview */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative w-full h-[380px] sm:h-[460px] rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 flex items-center justify-center p-4">
            {isProcessing && (
              <div className="absolute inset-0 z-20 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center text-white">
                <RefreshCw className="w-8 h-8 animate-spin text-blue-400" />
              </div>
            )}

            <img
              src={convertedDataUrl || image.dataUrl}
              alt="Format Output"
              className="max-h-full max-w-full object-contain rounded-lg"
            />
          </div>

          {/* Savings Metric Card */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-xs text-slate-500 font-medium block">Original Size</span>
              <span className="text-base font-bold text-slate-800 dark:text-slate-200">{formatBytes(image.size)}</span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-xs text-slate-500 font-medium block">Converted Size</span>
              <span className="text-base font-bold text-blue-600 dark:text-blue-400">
                {formatBytes(convertedSizeBytes)}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-xs text-slate-500 font-medium block">Size Impact</span>
              <span
                className={`text-base font-bold ${
                  savedBytes > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {savedBytes > 0 ? `-${savedPercent}% Saved` : 'Original Quality'}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Format Target Selection */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-6 shadow-sm">
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-blue-500" /> Choose Target Format
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {(
                [
                  { id: 'png', name: 'PNG', desc: 'Lossless & Transparency' },
                  { id: 'jpg', name: 'JPG', desc: 'Compact Photo Format' },
                  { id: 'jpeg', name: 'JPEG', desc: 'Standard Image' },
                  { id: 'webp', name: 'WEBP', desc: 'Modern High-Compress' },
                ] as const
              ).map((fmt) => (
                <button
                  key={fmt.id}
                  onClick={() => setTargetFormat(fmt.id)}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    targetFormat === fmt.id
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="font-bold text-sm">.{fmt.name}</div>
                  <div className={`text-[11px] mt-0.5 ${targetFormat === fmt.id ? 'text-blue-100' : 'text-slate-500'}`}>
                    {fmt.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Quality Slider (for JPG / WEBP) */}
          {(targetFormat === 'jpg' || targetFormat === 'jpeg' || targetFormat === 'webp') && (
            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-blue-500" /> Output Quality
                </span>
                <span className="font-mono text-blue-600 dark:text-blue-400">{quality}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <p className="text-[11px] text-slate-500">
                Lower quality reduces file size while maintaining sharp visuals.
              </p>
            </div>
          )}

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-2">
            <div className="flex items-center space-x-2 font-bold text-slate-900 dark:text-white">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Instant Local Conversion</span>
            </div>
            <p>
              Conversions happen 100% inside your browser session without sending files to any cloud API or external server.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
