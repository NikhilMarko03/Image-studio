import React, { useState } from 'react';
import { X, Download, FolderDown, FileText, Image, FolderSearch, Share2, HardDrive, Check, ExternalLink, Info } from 'lucide-react';
import { StorageDirectory, saveFileWithLocationOption, SaveResult } from '../utils/fileSaver';

interface SaveLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: string | Blob | null;
  defaultFilename: string;
  mimeType?: string;
  onSaveComplete: (result: SaveResult) => void;
}

export const SaveLocationModal: React.FC<SaveLocationModalProps> = ({
  isOpen,
  onClose,
  data,
  defaultFilename,
  mimeType,
  onSaveComplete,
}) => {
  const [filename, setFilename] = useState<string>(defaultFilename);
  const [selectedLocation, setSelectedLocation] = useState<StorageDirectory>('downloads');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [objectUrl, setObjectUrl] = useState<string | null>(null);

  // Sync defaultFilename and prepare object URL for direct link & preview
  React.useEffect(() => {
    if (isOpen && data) {
      setFilename(defaultFilename);
      setIsSaving(false);

      if (data instanceof Blob) {
        const url = URL.createObjectURL(data);
        setObjectUrl(url);
        return () => URL.revokeObjectURL(url);
      } else if (typeof data === 'string') {
        setObjectUrl(data);
      }
    } else {
      setObjectUrl(null);
    }
  }, [isOpen, data, defaultFilename]);

  if (!isOpen || !data) return null;

  const hasSystemPicker = typeof window !== 'undefined' && 'showSaveFilePicker' in window;
  const isImage = mimeType?.startsWith('image/') || defaultFilename.match(/\.(png|jpe?g|webp|gif|svg)$/i);

  const handleSave = async () => {
    if (!data) return;
    setIsSaving(true);
    try {
      const result = await saveFileWithLocationOption(
        data,
        filename.trim() || defaultFilename,
        selectedLocation,
        mimeType
      );
      onSaveComplete(result);
      onClose();
    } catch (err: any) {
      onSaveComplete({
        success: false,
        message: err.message || 'Failed to save file',
      });
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const locations = [
    {
      id: 'downloads' as StorageDirectory,
      title: 'Device Downloads Folder',
      description: 'Save directly to local storage / Downloads directory',
      icon: FolderDown,
      badge: 'Direct Local Save',
    },
    {
      id: 'documents' as StorageDirectory,
      title: 'Documents Folder',
      description: 'Save to device internal storage / Documents',
      icon: FileText,
    },
    {
      id: 'pictures' as StorageDirectory,
      title: 'Pictures / Gallery Storage',
      description: 'Save to device media & pictures folder',
      icon: Image,
    },
    {
      id: 'custom_picker' as StorageDirectory,
      title: 'System Folder Selector',
      description: 'Choose exact target directory on your device',
      icon: FolderSearch,
      badge: hasSystemPicker ? 'Folder Chooser' : 'OS Picker',
    },
    {
      id: 'system_share' as StorageDirectory,
      title: 'Share / Send Sheet',
      description: 'Send to Drive, Files app, or nearby devices',
      icon: Share2,
    },
  ];

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-white text-base">
                Save File to Local Device
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Choose location or save directly to device internal storage
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Filename Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              File Name
            </label>
            <input
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="Enter file name"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono"
            />
          </div>

          {/* Location Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2.5">
              Select Destination Storage Location
            </label>

            <div className="space-y-2">
              {locations.map((loc) => {
                const IconComponent = loc.icon;
                const isSelected = selectedLocation === loc.id;

                return (
                  <button
                    key={loc.id}
                    type="button"
                    onClick={() => setSelectedLocation(loc.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-blue-500 bg-blue-50/60 dark:bg-blue-950/30 ring-2 ring-blue-500/20'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div
                        className={`p-2 rounded-lg ${
                          isSelected
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-slate-900 dark:text-white truncate">
                            {loc.title}
                          </span>
                          {loc.badge && (
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                              {loc.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {loc.description}
                        </p>
                      </div>
                    </div>

                    <div className="ml-2 flex-shrink-0">
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                          isSelected
                            ? 'border-blue-600 bg-blue-600 text-white'
                            : 'border-slate-300 dark:border-slate-600'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Direct Link & Mobile Long-Press Box */}
          {objectUrl && (
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                <Info className="w-4 h-4 text-blue-500" />
                <span>Direct Save & Mobile Browser Options</span>
              </div>

              {isImage && (
                <div className="flex items-center space-x-3 pt-1">
                  <div className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-900 flex-shrink-0">
                    <img
                      src={objectUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    <strong>Mobile Tip:</strong> On mobile Chrome / browsers, you can also <strong>long-press</strong> the image preview on the left and tap <strong>"Download image"</strong> or <strong>"Save image"</strong> to save directly to Gallery.
                  </p>
                </div>
              )}

              <div className="pt-1 flex items-center justify-between border-t border-slate-200 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Alternative direct link:
                </span>
                <a
                  href={objectUrl}
                  download={filename.trim() || defaultFilename}
                  className="inline-flex items-center space-x-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                >
                  <span>Direct Download Link</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <button
            type="button"
            onClick={onClose}
            disabled={isSaving}
            className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-medium transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving || !filename.trim()}
            className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-sm font-semibold shadow-md transition-all disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save File Now'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

