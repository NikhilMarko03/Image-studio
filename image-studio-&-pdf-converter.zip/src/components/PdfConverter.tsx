import React, { useState } from 'react';
import { ImageFile, PdfSettings } from '../types';
import { generatePdfFromImages } from '../utils/pdfGenerator';
import { ImageUploader } from './ImageUploader';
import { FileText, Download, Trash2, ArrowUp, ArrowDown, Plus, Settings2, RefreshCw, CheckCircle } from 'lucide-react';
import { SaveLocationModal } from './SaveLocationModal';
import { SaveResult } from '../utils/fileSaver';

interface PdfConverterProps {
  initialImages?: ImageFile[];
}

export const PdfConverter: React.FC<PdfConverterProps> = ({ initialImages = [] }) => {
  const [images, setImages] = useState<ImageFile[]>(initialImages);
  const [settings, setSettings] = useState<PdfSettings>({
    pageSize: 'a4',
    orientation: 'portrait',
    margin: 'small',
    quality: 0.9,
    pdfName: 'document_export.pdf',
  });
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState<boolean>(false);

  const handleAddImages = (newImages: ImageFile[]) => {
    setImages((prev) => [...prev, ...newImages]);
  };

  const handleAddSingleImage = (newImg: ImageFile) => {
    setImages((prev) => [...prev, newImg]);
  };

  const handleRemoveImage = (id: string) => {
    setImages((prev) => prev.filter((img) => img.id !== id));
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= images.length) return;
    const copy = [...images];
    const temp = copy[index];
    copy[index] = copy[targetIndex];
    copy[targetIndex] = temp;
    setImages(copy);
  };

  const handleStartPdfSave = async () => {
    if (images.length === 0) return;
    setIsGenerating(true);
    setSuccessMessage(null);

    try {
      const generatedBlob = await generatePdfFromImages(images, settings);
      setPdfBlob(generatedBlob);
      setIsSaveModalOpen(true);
    } catch (err) {
      console.error('PDF Generation Error:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveComplete = (result: SaveResult) => {
    setSuccessMessage(result.message);
    setTimeout(() => setSuccessMessage(null), 5000);
  };

  const pdfFilename = settings.pdfName.endsWith('.pdf') ? settings.pdfName : `${settings.pdfName}.pdf`;

  return (
    <div className="w-full space-y-6">
      <SaveLocationModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        data={pdfBlob}
        defaultFilename={pdfFilename}
        mimeType="application/pdf"
        onSaveComplete={handleSaveComplete}
      />
      {/* If no images uploaded yet */}
      {images.length === 0 ? (
        <ImageUploader
          onImageSelected={handleAddSingleImage}
          onMultipleImagesSelected={handleAddImages}
          allowMultiple={true}
          title="Convert Images to PDF"
          subtitle="Select single or multiple photos to combine into a high-quality PDF document"
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: PDF Page Manager & Preview */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-500" />
                <h3 className="font-bold text-slate-900 dark:text-white">
                  Pages in PDF ({images.length})
                </h3>
              </div>

              <div className="flex items-center space-x-2">
                <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold px-3 py-2 rounded-xl transition-colors flex items-center gap-1.5">
                  <Plus className="w-4 h-4" />
                  <span>Add More Images</span>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files) {
                        const files = Array.from<File>(e.target.files);
                        Promise.all(
                          files.map(
                            (f: File) =>
                              new Promise<ImageFile>((resolve) => {
                                const reader = new FileReader();
                                reader.onload = (ev) => {
                                  const dataUrl = ev.target?.result as string;
                                  const img = new Image();
                                  img.onload = () => {
                                    resolve({
                                      id: Math.random().toString(36).substring(2, 9),
                                      name: f.name,
                                      type: f.type,
                                      size: f.size,
                                      width: img.width,
                                      height: img.height,
                                      dataUrl,
                                    });
                                  };
                                  img.src = dataUrl;
                                };
                                reader.readAsDataURL(f);
                              })
                          )
                        ).then(handleAddImages);
                      }
                    }}
                  />
                </label>
              </div>
            </div>

            {/* Notification message */}
            {successMessage && (
              <div className="flex items-center space-x-2 p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-semibold">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* Page Grid / List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {images.map((img, idx) => (
                <div
                  key={img.id}
                  className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center space-x-3 shadow-sm group hover:border-blue-400 transition-all"
                >
                  <div className="relative w-20 h-24 rounded-xl overflow-hidden bg-slate-950 shrink-0 border border-slate-700 flex items-center justify-center">
                    <img
                      src={img.processedUrl || img.dataUrl}
                      alt={`Page ${idx + 1}`}
                      className="max-h-full max-w-full object-contain"
                    />
                    <span className="absolute top-1 left-1 bg-blue-600 text-white font-bold text-[10px] px-1.5 py-0.5 rounded-md shadow">
                      P.{idx + 1}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {img.name}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {img.width} × {img.height} px
                    </p>
                    <div className="flex items-center space-x-1 pt-1">
                      <button
                        disabled={idx === 0}
                        onClick={() => handleMove(idx, 'up')}
                        className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 text-slate-600 dark:text-slate-300"
                        title="Move Up"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        disabled={idx === images.length - 1}
                        onClick={() => handleMove(idx, 'down')}
                        className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 text-slate-600 dark:text-slate-300"
                        title="Move Down"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleRemoveImage(img.id)}
                        className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-950 text-rose-600 transition-colors ml-auto"
                        title="Remove Page"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Page Setup & Download */}
          <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-5 shadow-sm">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
              <Settings2 className="w-4 h-4 text-blue-500" /> Page & PDF Setup
            </h3>

            {/* Document Title */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                PDF File Name
              </label>
              <input
                type="text"
                value={settings.pdfName}
                onChange={(e) => setSettings({ ...settings, pdfName: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Page Size */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Page Size
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'a4', label: 'A4' },
                  { id: 'letter', label: 'US Letter' },
                  { id: 'fit', label: 'Fit Image' },
                ].map((ps) => (
                  <button
                    key={ps.id}
                    onClick={() => setSettings({ ...settings, pageSize: ps.id as any })}
                    className={`py-2 text-xs font-bold rounded-xl border transition-colors ${
                      settings.pageSize === ps.id
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {ps.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Orientation */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Orientation
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'portrait', label: 'Portrait' },
                  { id: 'landscape', label: 'Landscape' },
                  { id: 'auto', label: 'Auto' },
                ].map((ori) => (
                  <button
                    key={ori.id}
                    onClick={() => setSettings({ ...settings, orientation: ori.id as any })}
                    className={`py-2 text-xs font-bold rounded-xl border transition-colors ${
                      settings.orientation === ori.id
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {ori.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Margins */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Page Margin
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'none', label: 'None (0mm)' },
                  { id: 'small', label: 'Small (10mm)' },
                  { id: 'large', label: 'Large (20mm)' },
                ].map((mg) => (
                  <button
                    key={mg.id}
                    onClick={() => setSettings({ ...settings, margin: mg.id as any })}
                    className={`py-2 text-[11px] font-bold rounded-xl border transition-colors ${
                      settings.margin === mg.id
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {mg.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Generate & Download Button */}
            <button
              onClick={handleStartPdfSave}
              disabled={isGenerating || images.length === 0}
              className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm py-3 px-4 rounded-xl shadow-lg transition-all disabled:opacity-50 pt-3"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Building PDF...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Generate & Download PDF</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
