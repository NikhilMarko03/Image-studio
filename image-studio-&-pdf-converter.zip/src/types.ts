export type TabType = 'bg-remover' | 'converter' | 'pdf' | 'resize';

export type OutputFormat = 'png' | 'jpeg' | 'jpg' | 'webp';

export interface ImageFile {
  id: string;
  name: string;
  type: string;
  size: number;
  width: number;
  height: number;
  dataUrl: string;
  processedUrl?: string;
  file?: File;
}

export interface BgRemovalSettings {
  mode: 'auto' | 'chroma' | 'manual';
  tolerance: number; // 0 - 100
  feather: number; // 0 - 20
  chromaColor: string; // hex #ffffff
  brushSize: number; // 5 - 100
  brushMode: 'erase' | 'restore';
  bgReplacement: 'transparent' | 'solid' | 'gradient' | 'blur';
  solidBgColor: string;
  gradientBg: string;
}

export interface ResizeSettings {
  mode: 'dimensions' | 'percentage';
  width: number;
  height: number;
  maintainAspectRatio: boolean;
  percentage: number;
  rotation: number; // 0, 90, 180, 270
  flipH: boolean;
  flipV: boolean;
  cropAspect?: 'free' | '1:1' | '4:3' | '16:9' | '9:16';
  brightness: number; // 100 default
  contrast: number; // 100 default
  saturation: number; // 100 default
  grayscale: boolean;
  sepia: boolean;
}

export interface PdfSettings {
  pageSize: 'a4' | 'letter' | 'fit';
  orientation: 'portrait' | 'landscape' | 'auto';
  margin: 'none' | 'small' | 'large';
  quality: number; // 0.1 - 1.0
  pdfName: string;
}

export interface FormatConvertSettings {
  targetFormat: OutputFormat;
  quality: number; // 0.1 - 1.0 (for jpg/webp)
}
